const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();

app.use(bodyParser.json());
app.use(cors());

let musicCollection = [];

app.get('/', (req, res) => {
  res.send('Server is running');
});

app.get('/music', (req, res) => {
  res.json(musicCollection);
});

app.post('/music', (req, res) => {
  const { title, url, publishDate } = req.body;
  musicCollection.push({ title, url, publishDate });
  res.sendStatus(201);
});

app.listen(process.env.PORT || 3000, () => {
  console.log('Server started on port ' + (process.env.PORT || 3000));
});
