package com.example.musicapp

import android.media.MediaPlayer
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import okhttp3.*
import org.json.JSONArray
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var mediaPlayer: MediaPlayer
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        loadMusic()

        playButton.setOnClickListener {
            if (mediaPlayer.isPlaying) {
                mediaPlayer.pause()
                playButton.text = "Play"
            } else {
                mediaPlayer.start()
                playButton.text = "Pause"
            }
        }
    }

    private fun loadMusic() {
        val request = Request.Builder()
            .url("https://replit.com/@sohemechac/music?v=1/music")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                // Handle error
            }

            override fun onResponse(call: Call, response: Response) {
                response.body?.let {
                    val jsonArray = JSONArray(it.string())
                    val song = jsonArray.getJSONObject(0) // Assuming first song
                    val songUrl = song.getString("url")
                    runOnUiThread {
                        songTitle.text = song.getString("title")
                        mediaPlayer = MediaPlayer().apply {
                            setDataSource(songUrl)
                            prepare()
                        }
                    }
                }
            }
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer.release()
    }
}
